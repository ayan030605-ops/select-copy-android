package com.example.selectcopy

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        val title = TextView(this).apply {
            text = "Select & Copy"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "\nЧтобы включить плавающую кнопку:\n\n1. Нажми кнопку ниже.\n2. Найди «Select & Copy» в списке специальных возможностей.\n3. Включи службу и подтверди разрешение.\n4. Вернись в Brave — появится плавающая кнопка.\n\nПри нажатии приложение скопирует текст, который Android сможет прочитать на текущей странице. Некоторые сайты и PDF могут отдавать не весь текст."
            textSize = 16f
        }
        val settings = Button(this).apply {
            text = "Открыть специальные возможности"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(settings)
        setContentView(layout)
    }
}
