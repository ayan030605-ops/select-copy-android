package com.example.selectcopy

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.Toast

class CopyAccessibilityService : AccessibilityService() {
    private lateinit var windowManager: WindowManager
    private var floatingButton: Button? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showFloatingButton()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        removeFloatingButton()
        super.onDestroy()
    }

    private fun showFloatingButton() {
        if (floatingButton != null) return

        val button = Button(this).apply {
            text = "📋 Копировать главу"
            isAllCaps = false
            textSize = 13f
            setOnClickListener { copyChapterText() }
            setOnTouchListener(DragTouchListener())
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18
            y = 420
        }

        try {
            windowManager.addView(button, params)
            floatingButton = button
            layoutParams = params
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось показать кнопку", Toast.LENGTH_SHORT).show()
        }
    }

    private fun removeFloatingButton() {
        val view = floatingButton ?: return
        try { windowManager.removeView(view) } catch (_: Exception) {}
        floatingButton = null
        layoutParams = null
    }

    private fun copyChapterText() {
        val roots = mutableListOf<AccessibilityNodeInfo>()

        // Prefer Brave's accessibility tree, not unrelated system/application windows.
        try {
            windows
                .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                .forEach { win ->
                    val root = win.root
                    if (root != null && root.packageName?.toString()?.contains("brave", ignoreCase = true) == true) {
                        roots.add(root)
                    }
                }
        } catch (_: Exception) {}

        if (roots.isEmpty()) {
            rootInActiveWindow?.let { roots.add(it) }
        }

        val chunks = mutableListOf<String>()
        roots.forEach { root -> collectText(root, chunks, 0) }

        val rawText = chunks.joinToString("\n\n")
        val chapter = extractFreeWebNovelChapter(rawText)

        if (chapter == null || chapter.isBlank()) {
            Toast.makeText(
                this,
                "Не удалось определить границы главы. Открой главу FreeWebNovel и попробуй ещё раз.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Текст главы", chapter))
        Toast.makeText(this, "Глава скопирована: ${chapter.length} символов", Toast.LENGTH_LONG).show()
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 100) return
        try {
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
            for (i in 0 until node.childCount) {
                collectText(node.getChild(i), out, depth + 1)
            }
        } catch (_: Exception) {
            // Some browser nodes can disappear while the page is changing.
        }
    }

    /**
     * FreeWebNovel-specific extraction:
     * - start at the final visible "Chapter N: ..." heading before the footer;
     * - stop before the site's Info / Comments / Saved / Library footer;
     * - retain paragraph breaks and punctuation.
     */
    private fun extractFreeWebNovelChapter(raw: String): String? {
        val text = raw
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .replace(Regex("[\\t ]+\\n"), "\n")
            .replace(Regex("\\n[\\t ]+"), "\n")

        if (text.isBlank()) return null

        val repeatedHeading = Regex("(?i)Chapter\\s+\\d+\\s*:\\s*Chapter\\s+\\d+\\s*:")
        val simpleHeading = Regex("(?i)Chapter\\s+\\d+\\s*:")
        val heading = repeatedHeading.findAll(text).lastOrNull()
            ?: simpleHeading.findAll(text).lastOrNull()
            ?: return null

        // Try to recover the novel title from the breadcrumb/title text before the chapter.
        val beforeHeading = text.substring(0, heading.range.first)
        val ignoredBefore = setOf(
            "Free Web Novel", "Home", "Your reading history", "Open navigation menu",
            "Prev Chapter", "Next Chapter", "Open chapter list", "Open reader settings"
        )
        val novelTitle = beforeHeading.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && it !in ignoredBefore }
            .filterNot { it.matches(Regex("(?i)Chapter\\s+\\d+\\s*:.*")) }
            .lastOrNull { it.length in 4..140 && !it.contains("Comments", true) }

        var body = text.substring(heading.range.first)

        // Collapse the duplicated heading prefix used by FreeWebNovel's reader.
        body = body.replaceFirst(
            Regex("(?i)^(Chapter\\s+\\d+\\s*:)\\s*Chapter\\s+\\d+\\s*:"),
            "$1"
        )

        // Stop at footer labels even when FreeWebNovel prefixes them with icon glyphs.
        val footer = Regex("(?im)^\\s*[^\\p{L}\\p{N}]*\\s*(?:Home|Info|Comments|Saved|Library|In Library)\\s*$")
        val footerMatch = footer.find(body)
        if (footerMatch != null) body = body.substring(0, footerMatch.range.first)

        body = body.lines().filterNot { line ->
            val v = line.trim()
            v.equals("Prev Chapter", true) ||
                v.equals("Next Chapter", true) ||
                v.equals("Open chapter list", true) ||
                v.equals("Open reader settings", true) ||
                v.matches(Regex("[“”‘’`]+"))
        }.joinToString("\n")

        body = body
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()

        if (body.length <= 80) return null
        return if (!novelTitle.isNullOrBlank()) "$novelTitle\n\n$body" else body
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            val params = layoutParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    return false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    if (moved) {
                        params.x = (startX - dx).coerceAtLeast(0)
                        params.y = (startY + dy).coerceAtLeast(0)
                        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                        return true
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) return true
            }
            return false
        }
    }
}
