package com.example.selectcopy

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.Toast

class CopyAccessibilityService : AccessibilityService() {
    private lateinit var windowManager: WindowManager
    private var floatingButton: Button? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showFloatingButton()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        removeFloatingButton()
        super.onDestroy()
    }

    private fun showFloatingButton() {
        if (floatingButton != null) return

        val button = Button(this).apply {
            text = "📋 Копировать всё"
            isAllCaps = false
            textSize = 13f
            setOnClickListener { copyActivePageText() }
            setOnTouchListener(DragTouchListener())
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18
            y = 420
        }

        try {
            windowManager.addView(button, params)
            floatingButton = button
            layoutParams = params
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось показать кнопку", Toast.LENGTH_SHORT).show()
        }
    }

    private fun removeFloatingButton() {
        val view = floatingButton ?: return
        try { windowManager.removeView(view) } catch (_: Exception) {}
        floatingButton = null
        layoutParams = null
    }

    private fun copyActivePageText() {
        val roots = mutableListOf<AccessibilityNodeInfo>()
        try {
            windows
                .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                .forEach { win -> win.root?.let { roots.add(it) } }
        } catch (_: Exception) {}

        if (roots.isEmpty()) rootInActiveWindow?.let { roots.add(it) }

        val chunks = LinkedHashSet<String>()
        roots.forEach { root ->
            collectText(root, chunks, 0)
        }

        val result = chunks
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotBlank() }
            .joinToString("\n")
            .trim()

        if (result.isBlank()) {
            Toast.makeText(this, "Текст страницы недоступен", Toast.LENGTH_LONG).show()
            return
        }

        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Текст страницы", result))
        Toast.makeText(this, "Скопировано: ${result.length} символов", Toast.LENGTH_LONG).show()
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableSet<String>, depth: Int) {
        if (node == null || depth > 80) return
        try {
            node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
            for (i in 0 until node.childCount) {
                collectText(node.getChild(i), out, depth + 1)
            }
        } catch (_: Exception) {
            // Some browser nodes become unavailable while the page is changing.
        }
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            val params = layoutParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    return false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    if (moved) {
                        params.x = (startX - dx).coerceAtLeast(0)
                        params.y = (startY + dy).coerceAtLeast(0)
                        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                        return true
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) return true
            }
            return false
        }
    }
}
