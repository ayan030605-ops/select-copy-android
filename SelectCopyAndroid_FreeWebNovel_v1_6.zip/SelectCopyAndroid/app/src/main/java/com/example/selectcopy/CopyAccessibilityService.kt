package com.example.selectcopy

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.Toast

class CopyAccessibilityService : AccessibilityService() {
    private lateinit var windowManager: WindowManager
    private var floatingButton: Button? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var copyInProgress = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showFloatingButton()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    override fun onDestroy() {
        removeFloatingButton()
        super.onDestroy()
    }

    private fun showFloatingButton() {
        if (floatingButton != null) return

        val button = Button(this).apply {
            text = "📋 Копировать главу"
            isAllCaps = false
            textSize = 13f
            setOnClickListener { startCopyWithRetries() }
            setOnTouchListener(DragTouchListener())
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18
            y = 420
        }

        try {
            windowManager.addView(button, params)
            floatingButton = button
            layoutParams = params
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось показать кнопку", Toast.LENGTH_SHORT).show()
        }
    }

    private fun removeFloatingButton() {
        val view = floatingButton ?: return
        try { windowManager.removeView(view) } catch (_: Exception) {}
        floatingButton = null
        layoutParams = null
    }

    /**
     * Brave may briefly expose an empty/incomplete accessibility tree while navigating
     * between chapters. Retry a few times instead of silently doing nothing.
     */
    private fun startCopyWithRetries() {
        if (copyInProgress) return
        copyInProgress = true
        Toast.makeText(this, "Получаю текст страницы…", Toast.LENGTH_SHORT).show()
        attemptCopy(attempt = 0)
    }

    private fun attemptCopy(attempt: Int) {
        val chapter = try {
            readChapterFromBrave()
        } catch (_: Exception) {
            null
        }

        if (!chapter.isNullOrBlank()) {
            try {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Текст главы", chapter))
                Toast.makeText(this, "Глава скопирована: ${chapter.length} символов", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось записать текст в буфер обмена. Попробуй ещё раз.", Toast.LENGTH_LONG).show()
            } finally {
                copyInProgress = false
            }
            return
        }

        if (attempt < 3) {
            mainHandler.postDelayed({ attemptCopy(attempt + 1) }, 350L)
        } else {
            copyInProgress = false
            Toast.makeText(
                this,
                "Текст главы пока недоступен. Дождись загрузки страницы и нажми ещё раз.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun readChapterFromBrave(): String? {
        val chunks = mutableListOf<String>()
        val seenRoots = mutableSetOf<Int>()

        // First inspect all Brave application windows (including reader/web-content windows).
        try {
            windows
                .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                .forEach { win ->
                    val root = try { win.root } catch (_: Exception) { null }
                    if (root != null && isBraveNode(root) && seenRoots.add(System.identityHashCode(root))) {
                        collectText(root, chunks, 0)
                    }
                }
        } catch (_: Exception) {
            // Window list can change while Brave is navigating; active-window fallback below.
        }

        // Fallback to the active root, but never read text from unrelated apps.
        if (chunks.isEmpty()) {
            val activeRoot = try { rootInActiveWindow } catch (_: Exception) { null }
            if (activeRoot != null && isBraveNode(activeRoot)) {
                collectText(activeRoot, chunks, 0)
            }
        }

        if (chunks.isEmpty()) return null
        val rawText = chunks.joinToString("\n\n")
        return extractFreeWebNovelChapter(rawText)
    }

    private fun isBraveNode(node: AccessibilityNodeInfo): Boolean =
        node.packageName?.toString()?.contains("brave", ignoreCase = true) == true

    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 100) return
        try {
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
            for (i in 0 until node.childCount) {
                collectText(node.getChild(i), out, depth + 1)
            }
        } catch (_: Exception) {
            // Some browser nodes can disappear while the page is changing.
        }
    }

    /**
     * FreeWebNovel-specific extraction:
     * - start at the final visible "Chapter N: ..." heading before the footer;
     * - stop before the site's Info / Comments / Saved / Library footer;
     * - retain paragraph breaks and punctuation.
     */
    private fun extractFreeWebNovelChapter(raw: String): String? {
        val text = raw
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .replace(Regex("[\\t ]+\\n"), "\n")
            .replace(Regex("\\n[\\t ]+"), "\n")

        if (text.isBlank()) return null

        val repeatedHeading = Regex("(?i)Chapter\\s+\\d+\\s*:\\s*Chapter\\s+\\d+\\s*:")
        val simpleHeading = Regex("(?i)Chapter\\s+\\d+\\s*:")
        val heading = repeatedHeading.findAll(text).lastOrNull()
            ?: simpleHeading.findAll(text).lastOrNull()
            ?: return null

        // Extract the novel title from the breadcrumb immediately before the chapter.
        // Ignore icons, Home, separators and other navigation labels.
        val ignored = setOf(
            "Home", "Free Web Novel", "Your reading history", "Open navigation menu",
            "Prev Chapter", "Next Chapter", "Open chapter list", "Open reader settings",
            "Info", "Comments", "Saved", "Library", "In Library"
        )
        val titleCandidates = text.substring(0, heading.range.first).lines()
            .map { cleanLabel(it) }
            .filter { it.length in 4..140 }
            .filterNot { it.equals("Home", true) || it.equals("Free Web Novel", true) }
            .filterNot { it in ignored }
            .filterNot { it.matches(Regex("[›>»|·•]+")) }
            .filterNot { it.contains("Chapter", true) || it.contains("Prev", true) || it.contains("Next", true) }
            .filterNot { it.contains("reading history", true) || it.contains("navigation menu", true) }

        // The breadcrumb may repeat the novel name; retain it once.
        val novelTitle = titleCandidates.lastOrNull()
            ?: titleCandidates.firstOrNull()

        var body = text.substring(heading.range.first)

        // Normalize the reader's duplicated chapter heading.
        body = body.replaceFirst(
            Regex("(?i)^(Chapter\\s+\\d+\\s*:)\\s*Chapter\\s+\\d+\\s*:"),
            "$1"
        )

        // Stop before footer labels, including labels preceded by decorative icon glyphs.
        val footer = Regex("(?im)^\\s*[^\\p{L}\\p{N}]*\\s*(?:Home|Info|Comments|Saved|Library|In Library)\\s*$")
        footer.find(body)?.let { body = body.substring(0, it.range.first) }

        body = body.lines().filterNot { line ->
            val label = cleanLabel(line)
            label.equals("Home", true) ||
                label.equals("Prev Chapter", true) ||
                label.equals("Next Chapter", true) ||
                label.equals("Open chapter list", true) ||
                label.equals("Open reader settings", true) ||
                label.matches(Regex("[›>»|·•]+")) ||
                label.matches(Regex("[“”‘’`]+"))
        }.joinToString("\n")

        // Remove navigation labels if the browser combines them with adjacent text nodes.
        body = body.replace(Regex("(?i)\\bNext\\s+Chapter\\s*[\\p{So}\\p{Sk}\\p{Punct}]*"), "")
        body = body.replace(Regex("(?i)\\bPrev\\s+Chapter\\s*[\\p{So}\\p{Sk}\\p{Punct}]*"), "")
        body = body
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()

        if (body.length <= 80) return null
        return if (!novelTitle.isNullOrBlank()) "$novelTitle\n\n$body" else body
    }

    private fun cleanLabel(value: String): String = value
        .replace(Regex("[^\\p{L}\\p{N}\\p{Punct} ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private inner class DragTouchListener : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            val params = layoutParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    return false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    if (moved) {
                        params.x = (startX - dx).coerceAtLeast(0)
                        params.y = (startY + dy).coerceAtLeast(0)
                        try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                        return true
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) return true
            }
            return false
        }
    }
}
